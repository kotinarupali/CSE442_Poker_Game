package PokerGame_GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Color;

import javax.swing.JPanel;
import java.awt.BorderLayout;

public class High_Card_view {

	private JFrame straightflush_frame_f = new JFrame("CheckPoint");
	private JButton back = new JButton("Back to main");
	private BufferedImage img;

	public High_Card_view() throws IOException {
		//////////////////////////////////////////////////
		// String path = "src\\Card_PNG\\2C.png";
		String path = "src\\Ranking_PNG\\High_Card.png";
		File file = new File(path);
		BufferedImage img = ImageIO.read(file);
		JLabel label = new JLabel(new ImageIcon(img));
		straightflush_frame_f.getContentPane().add(label);
		/////////////////////////////////////////////
		straightflush_frame_f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		straightflush_frame_f.getContentPane().add(panel, BorderLayout.NORTH);
		panel.add(back);
		back.setBackground(Color.GREEN);

		back.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				straightflush_frame_f.dispose();
				new PokerDesign();

			}

		});

		straightflush_frame_f.setVisible(true);
		straightflush_frame_f.pack();
	}

}

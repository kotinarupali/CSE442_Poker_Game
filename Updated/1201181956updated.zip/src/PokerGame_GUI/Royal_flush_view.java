package PokerGame_GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Color;

import javax.swing.JPanel;
import java.awt.BorderLayout;

public class Royal_flush_view {

	private JFrame f = new JFrame("CheckPoint");
	private JButton back = new JButton("Back to main");
	private BufferedImage img;

	public Royal_flush_view() throws IOException {
		//////////////////////////////////////////////////
		// String path = "src\\Card_PNG\\2C.png";
		String path = "src\\Ranking_PNG\\royal_flush.png";
		File file = new File(path);
		BufferedImage img = ImageIO.read(file);
		JLabel label = new JLabel(new ImageIcon(img));
		f.getContentPane().add(label);
		/////////////////////////////////////////////
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		f.getContentPane().add(panel, BorderLayout.NORTH);
		panel.add(back);
		back.setBackground(Color.GREEN);

		back.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				f.dispose();
				new PokerDesign();

			}

		});

		f.setVisible(true);
		f.pack();
		f.setExtendedState(f.getExtendedState() | JFrame.MAXIMIZED_BOTH);
	}

}

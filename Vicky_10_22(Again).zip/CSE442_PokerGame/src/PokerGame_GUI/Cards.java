package PokerGame_GUI;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;


public class Cards {
	
	private char[] _suitName = {'C', 'D', 'H', 'S'};
	private char[] _cardNum = {2,3,4,5,6,7,8,9,10,'J','K','Q','A'};
	
	public BufferedImage projectImage(String getCard) {
		String pngfile = "W:\\Eclipse\\CSE442_PokerGame\\src\\Card_PNG\\"+ getCard +".png";
		try {
			return ImageIO.read(new File(pngfile));
		} 
		catch (Exception e) {
			System.out.println("Image didn't print ");
			return null;
		}
	}
	

}

package PokerGame_GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;

public class PokerDesign {
	
	public PokerDesign(){
	JFrame guiFrame = new JFrame();
	guiFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	guiFrame.setTitle("Example GUI");
	guiFrame.setSize(500,500);
	guiFrame.setBackground(Color.black);
	guiFrame.setResizable(true);
	//Center Frame
	guiFrame.setLocationRelativeTo(null);
	//Options for the JComboBox
	
	
	String[] firstOptions = {"Rules", "Start Game", "Scoreboard"
	,"Shop"};
	//Getting rules here
	String[] Rules = new RuleReader().getRules("src\\PokerGame_GUI\\allPokerRules.txt");
	
	//The first JPanel contains a JLabel and JCombobox
	final JPanel comboPanel = new JPanel(new GridBagLayout());
	final JPanel picPanel = new JPanel(new GridBagLayout());
	JLabel picLabel = new JLabel(new ImageIcon(new Cards().projectImage("10"+"C")));
	picPanel.add(picLabel);
	
	GridBagConstraints gc = new GridBagConstraints();
	//gc.insets = new Insets(10,10,10,10);
	gc.gridx = 0;
	gc.gridy = 1;
	
	JLabel comboLbl = new JLabel("Select Action:");
	JComboBox dropList = new JComboBox(firstOptions);
	comboPanel.add(comboLbl,gc);
	gc.gridx = 1;
	comboPanel.add(dropList,gc);
	//comboPanel.add(picLabel);
	comboPanel.setBackground(Color.cyan);
	
	JLabel welcomeLabl = new JLabel("WELCOME TO THE POKER GAME");
	gc.gridx =0;
	gc.gridy = 2;
	comboPanel.add(welcomeLabl,gc);
	
	//Create the second JPanel. Add a JLabel and JList and
	//make use the JPanel is not visible.
	final JPanel listPanel = new JPanel(new GridBagLayout());
	GridBagConstraints lc = new GridBagConstraints();
	lc.gridx =0; lc.gridy =0;
	
	
	
	listPanel.setVisible(false);
	JLabel listLbl = new JLabel("BEST HANDS POSSIBLE");
	JList ruleList = new JList(Rules);
	ruleList.setLayoutOrientation(JList.VERTICAL);
	listPanel.add(listLbl);
	
	lc.gridx = 0; lc.gridy = 1;
	listPanel.add(ruleList,lc);
	
	
	JButton begButton = new JButton("BEGIN");
	
	begButton.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent event){
		if(dropList.getSelectedItem().equals("Rules")) {
			comboPanel.setVisible(false);
			listPanel.setVisible(true);
			
		}
		else if(dropList.getSelectedItem().equals("Start Game")) {
			comboPanel.setVisible(false);
			picPanel.setVisible(true);
		}
		else
		comboPanel.setVisible(true);
		}
	});
	
	gc.gridx =1;
	gc.gridy = 3;
	comboPanel.add(begButton, gc);
	
	
	guiFrame.add(comboPanel, BorderLayout.NORTH);
	guiFrame.add(picPanel, BorderLayout.CENTER);
	guiFrame.add(listPanel, BorderLayout.CENTER);
	//guiFrame.add(begButton,BorderLayout.SOUTH);
	
	//make sure the JFrame is visible
	guiFrame.setVisible(true);
	}
	
}

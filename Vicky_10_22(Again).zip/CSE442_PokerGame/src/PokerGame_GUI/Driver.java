package PokerGame_GUI;

/**
 * The driver for homework three. CSE 331
 */

public class Driver {
//Note: Typically the main method will be in a
//separate class. As this is a simple one class
//example it's all in the one class.
public static void main(String[] args) {
new PokerDesign();
}

}


package ub.cse.algo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Queue;
import java.util.LinkedList;

public class Solution {
	  private int startNode;
	  private HashMap<Integer, ArrayList<Integer>> graph;
	  public Solution(int node, HashMap<Integer, ArrayList<Integer>> g){
	    startNode = node;
	    graph = g;
	  }

	  public int[] outputDistances(){
		 Queue<Integer> nodes = new LinkedList<Integer>();
		 boolean[] CC = new boolean[graph.size()];
		 int[] prevNode = new int[graph.size()];
		 int[] retDist = new int[graph.size()];
		 
		 for(int i =0; i<CC.length; i++) {
			 CC[i] = false;
			 prevNode[i] = -1;
		 }
		 
		 nodes.add(startNode);
		 CC[startNode] = true;
		 
		 
		 while(!nodes.isEmpty()){
			 int pN = nodes.poll();
			 ArrayList<Integer> cN = graph.get(pN);
			 for(int i = 0; i < cN.size(); i++) {
				 if(CC[cN.get(i)] == false) {
					 CC[cN.get(i)] = true;
					 prevNode[cN.get(i)] = pN;
					 nodes.add(cN.get(i));
				 }
			 }
		 }
		 
		 for(int j =0; j < prevNode.length; j++) {
			 int destinNode = j;
			 if(CC[destinNode] == true) {
				 int total = 0;
				 while(destinNode != startNode) {
					 int temp = prevNode[destinNode];
					 destinNode = temp;
					 total++;
				 }
				 retDist[j] = total;
			 }
			 else {
				 retDist[j] = -1;
			 }
			 
		 }
		 
	    return retDist;
	  }
}
